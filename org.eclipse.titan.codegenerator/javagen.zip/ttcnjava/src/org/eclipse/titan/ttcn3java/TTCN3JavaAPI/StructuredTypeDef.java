package org.eclipse.titan.ttcn3java.TTCN3JavaAPI;

public abstract class StructuredTypeDef extends TypeDef {

}