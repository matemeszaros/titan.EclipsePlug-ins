package org.eclipse.titan.ttcn3java.TTCN3JavaAPI;

import java.io.Serializable;

public class ModuleDef implements Serializable{
}
