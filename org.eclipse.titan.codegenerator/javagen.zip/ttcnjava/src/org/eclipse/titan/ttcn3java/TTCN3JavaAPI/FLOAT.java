package org.eclipse.titan.ttcn3java.TTCN3JavaAPI;

public class FLOAT extends Arithmetical<FLOAT> {

    public Double value;

    public FLOAT() {

    }

    public FLOAT(Double value) {
        this.value = value;
    }

    public FLOAT plus(FLOAT aFloat) {
        return new FLOAT(value + aFloat.value);
    }

    public FLOAT minus(FLOAT aFloat) {
        return new FLOAT(value - aFloat.value);
    }

    public FLOAT multipleBy(FLOAT aFloat) {
        return new FLOAT(value * aFloat.value);
    }

    public FLOAT divideBy(FLOAT aFloat) {
        return new FLOAT(value / aFloat.value);
    }

    public BOOLEAN isGreaterThan(FLOAT aFloat) {
        return new BOOLEAN(value > aFloat.value);
    }

    public BOOLEAN isGreaterOrEqualThan(FLOAT aFloat) {
    	return new BOOLEAN(value >= aFloat.value);
    }

    public BOOLEAN isLessThan(FLOAT aFloat) {
    	return new BOOLEAN(value < aFloat.value);
    }

    public BOOLEAN isLessOrEqualThan(FLOAT aFloat) {
    	return new BOOLEAN(value <= aFloat.value);
    }

    public BOOLEAN equalsWith(FLOAT aFloat) {
    	return new BOOLEAN(value.equals(aFloat.value));
    }

    public BOOLEAN notEqualsWith(FLOAT aFloat) {
    	return new BOOLEAN(!value.equals(aFloat.value));
    }

	public String toString() {
		return toString("");
	}
	
	public String toString(String tabs){
		if(anyField) return "?";
		if(omitField) return "omit";
		if(anyOrOmitField) return "*";
		return value.toString();
    }
    
}
