package org.eclipse.titan.ttcn3java.TTCN3JavaAPI;

public abstract class UnionDef extends StructuredTypeDef {

}