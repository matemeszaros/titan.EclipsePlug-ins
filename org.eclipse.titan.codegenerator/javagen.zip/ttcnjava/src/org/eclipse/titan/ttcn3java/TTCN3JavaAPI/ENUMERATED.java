package org.eclipse.titan.ttcn3java.TTCN3JavaAPI;

import java.util.HashMap;

public class ENUMERATED extends Relational<ENUMERATED> {

	protected String value;
	public HashMap<String,Integer> values;
	
	public void setValue(String v) throws IndexOutOfBoundsException{
		if(values.keySet().contains(v)) value=v;
		else{
			throw new IndexOutOfBoundsException("Illegal ENUMERATED value.");
		}
	}
	
	public ENUMERATED(){
		values = new HashMap<String,Integer>();
	}
	
	public String getValue(){
		return value;
	}
	
    public BOOLEAN isGreaterThan(ENUMERATED enumerated) {
        return new BOOLEAN(false);
    }

    public BOOLEAN isGreaterOrEqualThan(ENUMERATED enumerated) {
        return new BOOLEAN(false);
    }

    public BOOLEAN isLessThan(ENUMERATED enumerated) {
        return new BOOLEAN(false);
    }

    public BOOLEAN isLessOrEqualThan(ENUMERATED enumerated) {
        return new BOOLEAN(false);
    }

    public BOOLEAN equalsWith(ENUMERATED enumerated) {
        return new BOOLEAN(false);
    }
    
    public static boolean match(ENUMERATED pattern, Object message){
    	if(!(message instanceof ENUMERATED)) return false;
    	if(pattern.omitField&&((ENUMERATED)message).omitField) return true;
    	if(pattern.anyOrOmitField) return true;
    	if(pattern.anyField&&!((ENUMERATED)message).omitField) return true;
    	if(pattern.omitField&&!((ENUMERATED)message).omitField) return false;
    	if(pattern.anyField&&((ENUMERATED)message).anyField) return false;
    	return (pattern.getValue().equals(((ENUMERATED)message).getValue()));
    }
    
	public boolean equals(ENUMERATED v){
		return this.value.equals(v.getValue());
	}
	
	public String toString() {
		return toString("");
	}
	
	public String toString(String tabs){
		return getValue();
	}
    
}
