package org.eclipse.titan.ttcn3java.TTCN3JavaAPI;

public class BOOLEAN extends Comparable<BOOLEAN>{

    Boolean value;

    public BOOLEAN(boolean value){
        this.value = value;
    }
	
    public BOOLEAN equalsWith(BOOLEAN aBoolean) {
        return new BOOLEAN(value == aBoolean.value);
    }

    public BOOLEAN not(){
        return new BOOLEAN(!value);
    }

    public BOOLEAN and(BOOLEAN b){
        return new BOOLEAN(value && b.value);
    }

    public BOOLEAN or(BOOLEAN b){
        return new BOOLEAN(value || b.value);
    }

    public BOOLEAN xor(BOOLEAN b) {
        return new BOOLEAN(value ^ b.value);
    }
    
	public String toString(){
		return toString("");
	}
	
	public String toString(String tabs){
		if(anyField) return "?";
		if(omitField) return "omit";
		if(anyOrOmitField) return "*";
		return Boolean.toString(value);
	}
	
}
