package org.eclipse.titan.ttcn3java.TTCN3JavaAPI;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import org.eclipse.titan.javagen.*;

public abstract class ComponentDef extends ModuleDef{
    public boolean created = false; //state variable
    
    public BlockingQueue<Boolean> donequeue = new ArrayBlockingQueue<Boolean>(1024);
    public String name;
    public Thread thread;
	public abstract void prepareforconnection(String thisport, int thisportnum);
	public abstract void connect(String port, String ip, String portnum);
    public HCType hc;
    public String compid;
	
    public BlockingQueue<Boolean> queue = new ArrayBlockingQueue<Boolean>(1024);
    private int verdict; //0-none, 1-pass, 2-inconc, 3-fail, 4-error

    public ComponentDef(String n) {
    	name = n;
        setVerdict("none");
    }

    public void setVerdict(String s) {
        int v = -1;
        if (s == "none") v = 0;
        if (s == "pass") v = 1;
        if (s == "inconc") v = 2;
        if (s == "fail") v = 3;
        if (s == "error") v = 4;
        if (v > verdict) verdict = v;
    }
    
    public int getVerdictInt(){
    	return verdict;
    }
    
    public String getVerdict(){
    	if(verdict==0) return "none";
    	if(verdict==1) return "pass";
    	if(verdict==2) return "inconc";
    	if(verdict==3) return "fail";
    	if(verdict==4) return "error";
    	return "";
    }
}
