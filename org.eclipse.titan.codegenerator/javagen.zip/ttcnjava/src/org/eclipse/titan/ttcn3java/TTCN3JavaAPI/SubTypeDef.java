package org.eclipse.titan.ttcn3java.TTCN3JavaAPI;

import java.util.ArrayList;
import java.util.List;

public abstract class SubTypeDef<T extends PrimitiveTypeDef> extends PrimitiveTypeDef{
    protected List<T> allowedValues; //allowed values of subtype
    protected List<SubTypeInterval<T>> allowedIntervals; //allowed intervals of subtype

    public T value;

    public SubTypeDef() {
        allowedValues = new ArrayList<T>();
        allowedIntervals = new ArrayList<SubTypeInterval<T>>();
    }

    public SubTypeDef(T val) {
    	this();
    	value = val;
    }

    public void checkValue() throws IndexOutOfBoundsException {
        if (allowedValues.size() == 0 && allowedIntervals.size() == 0)
            return;
        for (SubTypeInterval<T> i : allowedIntervals)
            if(i.checkValue(value)) return;
        for (T i : allowedValues)
            if (i.equals(value)) return;
        throw new IndexOutOfBoundsException("out of intervals!");
    }

    public String toString(){
    	return toString("");
    }
    
    public String toString(String tabs){
    	return value.toString();
    }
}