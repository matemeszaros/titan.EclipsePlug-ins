package org.eclipse.titan.ttcn3java.TTCN3JavaAPI;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public abstract class RecordDef extends StructuredTypeDef {
    public List<String> fieldsInOrder; //stores the order of fields of record type
    
    public RecordDef(){
    	fieldsInOrder = new ArrayList<String>();
    }
    
}