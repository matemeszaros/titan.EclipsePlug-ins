package org.eclipse.titan.ttcn3java.TTCN3JavaAPI;

public abstract class PrimitiveTypeDef extends TypeDef{

}