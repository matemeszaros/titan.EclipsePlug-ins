package org.eclipse.titan.ttcn3java.TTCN3JavaAPI;

public class TTCNJavaAPIException extends Exception {
	public TTCNJavaAPIException(String s){
		super(s);
	}
}
