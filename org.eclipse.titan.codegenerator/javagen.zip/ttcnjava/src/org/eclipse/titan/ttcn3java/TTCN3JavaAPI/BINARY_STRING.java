package org.eclipse.titan.ttcn3java.TTCN3JavaAPI;

//maybe this should be abstract and the fromXXX methods should be removed.

public class BINARY_STRING extends STRING{

	public BINARY_STRING(){
	}

	public BINARY_STRING(String s){
		super(s);
	}
	
	protected int fromBitString(byte[] b){
		String str = new String(b);
		return Integer.parseInt(str, 2);
	}
	
	protected int fromOctetString(byte[] b){
		String str = new String(b);
		return Integer.parseInt(str, 8);
	}
	
	protected int fromHexString(byte[] b){
		String str = new String(b);
		return Integer.parseInt(str, 16);
	}
	
    public int generalBitwiseNot(int o1){
        return ~o1;
    }

    public int generalBitwiseAnd(int o1, int o2){
        return o1 & o2;
    }

    public int generalBitwiseOr(int o1, int o2){
        return o1 | o2;
    }

    public int generalBitwiseXor(int o1, int o2){
        return o1 ^ o2;
    }

    public BINARY_STRING shiftLeft(INTEGER by){
        byte[] copy = new byte[value.length];
        for(int i=0;i<copy.length;i++){
            copy[i]=0;
        }
        int byValue = by.value;
        if(byValue >= value.length){
            return new BINARY_STRING(new String(copy));
        }
        System.arraycopy(value,byValue,copy,0,value.length-byValue);
        return new BINARY_STRING(new String(copy));
    }

    public BINARY_STRING shiftRight(INTEGER by){
        byte[] copy = new byte[value.length];
        for(int i=0;i<copy.length;i++){
            copy[i]=0;
        }
        int byValue = by.value;
        if(byValue >= value.length){
            return new BINARY_STRING(new String(copy));
        }
        System.arraycopy(value,0,copy,byValue,value.length-byValue);
        return new BINARY_STRING(new String(copy));
    }
    
}
