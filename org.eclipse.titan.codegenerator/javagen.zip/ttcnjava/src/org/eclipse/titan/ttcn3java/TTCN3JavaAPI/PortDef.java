package org.eclipse.titan.ttcn3java.TTCN3JavaAPI;

public class PortDef extends ModuleDef {
    protected ComponentDef component; //component including port instance
    public String name;

    public ComponentDef GetComponent() {
        return component;
    }
}