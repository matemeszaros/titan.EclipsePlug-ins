package org.eclipse.titan.ttcn3java.TTCN3JavaAPI;

public class INTEGER extends Arithmetical<INTEGER> {

    Integer value;

    public INTEGER() {

    }

    public INTEGER(Integer value) {
        this.value = value;
    }

    public INTEGER rem(INTEGER divider){
        Integer val = value - divider.value * (value/divider.value);
        return new INTEGER(val);
    }

    public INTEGER mod(INTEGER divider){
        if(value >= 0) {
            if (divider.value < 0) {
                return rem(new INTEGER(divider.value * -1));
            } else {
                return rem(divider);
            }
        } else if (value < 0 && rem(this).equalsWith(new INTEGER(0)).value) {
            return new INTEGER(0);
        } else {
            return new INTEGER(divider.value * -1).plus(rem(new INTEGER(divider.value * -1)));
        }
    }

    public INTEGER plus(INTEGER integer) {
        return new INTEGER(integer.value + value);
    }

    public INTEGER minus(INTEGER integer) {
        return new INTEGER(value - integer.value);
    }

    public INTEGER multipleBy(INTEGER integer) {
        return new INTEGER(value * integer.value);
    }

    public INTEGER divideBy(INTEGER integer) {
        return new INTEGER(value / integer.value);
    }

    public BOOLEAN isGreaterThan(INTEGER integer) {
        return new BOOLEAN(value > integer.value);
    }

    public BOOLEAN isGreaterOrEqualThan(INTEGER integer) {
        return new BOOLEAN(value >= integer.value);
    }

    public BOOLEAN isLessThan(INTEGER integer) {
        return new BOOLEAN(value < integer.value);
    }

    public BOOLEAN isLessOrEqualThan(INTEGER integer) {
        return new BOOLEAN(value <= integer.value);
    }

    public BOOLEAN equalsWith(INTEGER integer) {
        return new BOOLEAN(value.equals(integer.value));
    }

    public static boolean match(INTEGER pattern, INTEGER message){
        if(pattern.omitField&&message==null) return true; 
        if(pattern.anyOrOmitField) return true; 
        if(pattern.anyField&&message!=null) return true;
        if(pattern.omitField&&message!=null) return false;
        if(pattern.anyField&&message==null) return false;
        return (pattern.value.equals(message.value));
    }
    
	public boolean equals(INTEGER v){
		return this.value.equals(v.value);
	}
	
	public CHARSTRING int2str(){
		return new CHARSTRING(Integer.toString(this.value));
	}
	
	public String toString() {
		return toString("");
	}
	
	public String toString(String tabs){
		if(anyField) return "?";
		if(omitField) return "omit";
		if(anyOrOmitField) return "*";
    	return value.toString();
    }
    
}
