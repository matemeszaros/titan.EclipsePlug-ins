package org.eclipse.titan.ttcn3java.TTCN3JavaAPI;

public abstract class Comparable<T> extends PrimitiveTypeDef {

	public abstract BOOLEAN equalsWith(T t);
	
}