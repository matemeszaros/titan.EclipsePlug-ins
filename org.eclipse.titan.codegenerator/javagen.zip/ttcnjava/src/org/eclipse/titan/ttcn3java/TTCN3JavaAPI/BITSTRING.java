package org.eclipse.titan.ttcn3java.TTCN3JavaAPI;

public class BITSTRING extends BINARY_STRING{

    public BITSTRING(){
    }

    public BITSTRING(String inputvalue) {
        super(inputvalue);
        Integer.parseInt(inputvalue, 2); //Throws an exception if not legal
    }
    
    public BITSTRING bitwiseNot(){
    	return new BITSTRING(Integer.toBinaryString(generalBitwiseNot(fromBitString(value))));
    }    

    public BITSTRING bitwiseAnd(BITSTRING b){
    	return new BITSTRING(Integer.toBinaryString(generalBitwiseAnd(fromBitString(value), fromBitString(b.value))));
    }
    
    public BITSTRING bitwiseOr(BITSTRING b){
    	return new BITSTRING(Integer.toBinaryString(generalBitwiseOr(fromBitString(value), fromBitString(b.value))));
    }
    
    public BITSTRING bitwiseXor(BITSTRING b){
    	return new BITSTRING(Integer.toBinaryString(generalBitwiseXor(fromBitString(value), fromBitString(b.value))));
    }
    
	public String toString() {
		return toString("");
	}
	
	public String toString(String tabs){
		if(anyField) return "?";
		if(omitField) return "omit";
		if(anyOrOmitField) return "*";
		return "B'" + new String(value) + "'";
	}

}