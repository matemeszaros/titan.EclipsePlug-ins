package org.eclipse.titan.ttcn3java.TTCN3JavaAPI;

public abstract class Relational<T> extends Comparable<T> {

    public abstract BOOLEAN isGreaterThan(T t);

    public abstract BOOLEAN isGreaterOrEqualThan(T t);

    public abstract BOOLEAN isLessThan(T t);

    public abstract BOOLEAN isLessOrEqualThan(T t);

}
