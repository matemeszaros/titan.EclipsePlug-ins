package org.eclipse.titan.ttcn3java.TTCN3JavaAPI;

public abstract class Arithmetical<T> extends Relational<T> {

    public abstract T plus(T t);

    public abstract T minus(T t);

    public abstract T multipleBy(T t);

    public abstract T divideBy(T t);

}
