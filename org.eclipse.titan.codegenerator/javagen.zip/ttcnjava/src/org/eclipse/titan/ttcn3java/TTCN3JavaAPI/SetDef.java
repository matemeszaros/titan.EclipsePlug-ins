package org.eclipse.titan.ttcn3java.TTCN3JavaAPI;

import java.util.Set;

public abstract class SetDef extends StructuredTypeDef {

}