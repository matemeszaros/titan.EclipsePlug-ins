package org.eclipse.titan.ttcn3java.TTCN3JavaAPI;

public class OCTETSTRING extends BINARY_STRING {

    public OCTETSTRING() {
    }

    public OCTETSTRING(String value) {
        super(value);
        Integer.parseInt(value, 8); //throws an exception if not legal
    }
    
    public OCTETSTRING bitwiseNot(){
    	return new OCTETSTRING(Integer.toOctalString(generalBitwiseNot(fromOctetString(value))));
    }    

    public OCTETSTRING bitwiseAnd(OCTETSTRING b){
    	return new OCTETSTRING(Integer.toOctalString(generalBitwiseAnd(fromOctetString(value), fromOctetString(b.value))));
    }
    
    public OCTETSTRING bitwiseOr(OCTETSTRING b){
    	return new OCTETSTRING(Integer.toOctalString(generalBitwiseOr(fromOctetString(value), fromOctetString(b.value))));
    }
    
    public OCTETSTRING bitwiseXor(OCTETSTRING b){
    	return new OCTETSTRING(Integer.toOctalString(generalBitwiseXor(fromOctetString(value), fromOctetString(b.value))));
    }
    
	public String toString() {
		return toString("");
	}
	
	public String toString(String tabs){
		if(anyField) return "?";
		if(omitField) return "omit";
		if(anyOrOmitField) return "*";
		return "O'" + new String(value) + "'";
	}
    
}
