package org.eclipse.titan.ttcn3java.TTCN3JavaAPI;

public class STRING extends Comparable<STRING>{

    public byte[] value;

    public STRING() {
    	value = null;
    }

    public STRING(String s) {
        this.value = s.getBytes();
    }

    public STRING concatenate(STRING other){
    	return new STRING(this.value.toString() + other.value.toString());
    }

    public BOOLEAN equalsWith(STRING string) {
    	return new BOOLEAN(this.value.equals(string.value));
    }


    public STRING rotateLeft(INTEGER by){
        byte[] copy = new byte[value.length];
        int byValue = by.value % value.length;
        System.arraycopy(value,byValue,copy,0,value.length-byValue);
        System.arraycopy(value,0,copy,value.length-byValue,byValue);
        return new STRING(new String(copy));
    }

    public STRING rotateRight(INTEGER by) {
        int byValue = by.value % value.length;
        return rotateLeft(new INTEGER(value.length-byValue));
    }
    
    public static boolean match(STRING pattern, Object message){
    	if(!(message instanceof STRING)) return false;
    	if(pattern.omitField&&((STRING)message).omitField) return true;
    	if(pattern.anyOrOmitField) return true;
    	if(pattern.anyField&&!((STRING)message).omitField) return true;
    	if(pattern.omitField&&!((STRING)message).omitField) return false;
    	if(pattern.anyField&&((STRING)message).anyField) return false;
        return (pattern.equals(((STRING)message)));
    }
    
	public boolean equals(STRING v){
		for(int i=0;i<value.length;i++)
			if(this.value[i]!=v.value[i]) return false;
		return true;
	}

	/* these are never used, only needed because STRING cannot be an abstract class due to its operator methods
	 * the results of which on the other hand, will always be cast to the corresponding child classes
	 */
	
	public String toString(String tabs) {
		return null;
	}

	public String toString() {
		return null;
	}

}
