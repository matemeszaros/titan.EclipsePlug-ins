package org.eclipse.titan.ttcn3java.TTCN3JavaAPI;

public class SubTypeInterval<T> {
    T lowerbound;
    T upperbound;

    public SubTypeInterval(T lower, T upper) {
        lowerbound=lower;
        upperbound=upper;
    }

    boolean checkValue(T value) {
    	if(lowerbound instanceof Relational<?>)
    		return ((Relational<T>)lowerbound).isLessOrEqualThan(value).value&&((Relational<T>)upperbound).isGreaterOrEqualThan(value).value;
    	else throw new IndexOutOfBoundsException("bound is not relational");
    }
}