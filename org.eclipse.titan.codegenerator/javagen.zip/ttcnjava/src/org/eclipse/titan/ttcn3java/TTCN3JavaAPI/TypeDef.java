package org.eclipse.titan.ttcn3java.TTCN3JavaAPI;

public abstract class TypeDef extends ModuleDef{
    public boolean anyField; //stores if the given data instance has special value ?
    public boolean omitField; //stores if the given data instance has special value omit
    public boolean anyOrOmitField; //stores if the given data instance has special value *
    
    public abstract String toString(String tabs);
    public abstract String toString();
    
}