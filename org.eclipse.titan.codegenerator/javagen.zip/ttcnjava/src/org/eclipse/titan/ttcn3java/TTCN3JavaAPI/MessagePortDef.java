package org.eclipse.titan.ttcn3java.TTCN3JavaAPI;

import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class MessagePortDef extends PortDef {
    public Set<String> inMessages; //input type names of port type 
    public Set<String> outMessages; //output type names of port type
    protected boolean created = false;
    protected boolean mapped = false;
    public MessagePortDef mappedto;

    public List<Object> inBuffer; //input buffer

    public MessagePortDef(ComponentDef c, String name) {
        component = c;
        this.name=name;
        inMessages = new TreeSet<String>();
        outMessages = new TreeSet<String>();
    }

    public void enqueue(Object o){ //putting incoming messages to inBuffer
    	if (!mapped){
    		TTCN3Logger.writeLog(component.name + ":" + name, "PORTEVENT", "Cannot enqueue message--Port not mapped", false);//!uj
        	return;
    	}
    	inBuffer.add(o);
    	component.queue.add(true);
    }
}