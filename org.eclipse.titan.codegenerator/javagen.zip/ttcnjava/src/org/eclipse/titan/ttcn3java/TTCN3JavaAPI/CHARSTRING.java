package org.eclipse.titan.ttcn3java.TTCN3JavaAPI;

public class CHARSTRING extends STRING{

    public CHARSTRING(String value) {
    	super(value);
    	//TODO check whether it really is a charstring
    }

    public CHARSTRING() {
    }
    
	public String toString() {
		return toString("");
	}
	
	//needed even though tabs is not used, since otherwise the method of STRING would run and return null
	public String toString(String tabs){
		if(anyField) return "?";
		if(omitField) return "omit";
		if(anyOrOmitField) return "*";
		return "\"" + new String(value) + "\"";
	}
    
}
