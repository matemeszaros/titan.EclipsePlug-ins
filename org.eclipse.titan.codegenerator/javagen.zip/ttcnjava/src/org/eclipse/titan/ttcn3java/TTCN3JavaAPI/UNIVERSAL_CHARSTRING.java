package org.eclipse.titan.ttcn3java.TTCN3JavaAPI;

public class UNIVERSAL_CHARSTRING extends CHARSTRING{

	public UNIVERSAL_CHARSTRING(String s){
		super(s);
		//ellenorzes
	}
	
	public UNIVERSAL_CHARSTRING(){
		
	}

}
