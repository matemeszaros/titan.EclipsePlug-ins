package org.eclipse.titan.ttcn3java.TTCN3JavaAPI;

import java.util.List;

public abstract class RecordOfDef<T extends TypeDef> extends StructuredTypeDef {
    List<T> value;
    
    public boolean equals(RecordOfDef<T> v) {
        if (this.value.size() != v.value.size()) return false;
        for (int i = 0; i < this.value.size(); i++)
            if (!(this.value.get(i).equals(v.value.get(i)))) return false;
        return true;
    }
    
    public String toString(){//!uj egesz metodus, ez minden tipusnal ugyanigy mukodik
    	return toString("");
    }
    
    public String toString(String tabs){
		if(anyField) return "?";
		if(omitField) return "omit";
		if(anyOrOmitField) return "*";
    	String retv = "[";
    	for(int i=0;i<value.size();i++){
    		retv += value.get(i).toString(tabs);
    		if(i<value.size()-1) retv += ",";
    	}
    	retv += "]";
    	return retv;
    }
}