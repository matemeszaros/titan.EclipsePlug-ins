package org.eclipse.titan.codegenerator.javagen;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;
import java.util.Vector;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

import org.eclipse.titan.codegenerator.TTCN3JavaAPI.*;
public class TP_HTTPmsg_PT {
	private Socket s;
	private HTTPmsg_PT port;
	private PrintWriter pw;
	private BlockingQueue<Boolean> socketon = new ArrayBlockingQueue<Boolean>(1024);
	private boolean ispersistent=true;
	private boolean isclient;
	private boolean isinitialized=false; //connect or listen asp received
	private TestPortDaemon daemon;
	public TP_HTTPmsg_PT(HTTPmsg_PT p){
		port=p;
	}
	//must block until map is done
	public void user_map(String remotecomp, String remoteport){
		port.mapped=true; //in this case, mapping is done by Connect and Listen ASPs, so send can be called prior to mapped being true
	}
	//must block until unmap is done
	public void user_unmap(String remotecomp, String remoteport){ 
	}
	public void user_send(Object o){
		if(o instanceof Connect){
			if(isinitialized) System.out.println("TEST PORT ALREADY INITIALIZED"); //test port error - TODO
			isclient=true;
			Connect c = (Connect)o;
			String hostname = new String(c.hostname.value);
			int port = c.portnumber.value.intValue();
			try {
				s = new Socket(InetAddress.getByName(hostname), port); //!!
				this.socketon.add(true);
				pw = new PrintWriter(s.getOutputStream());
			} catch (Exception e) {e.printStackTrace();}
			(daemon = new TestPortDaemon(this)).start(); //here it is known whether the tester is a server or a client - so the daemon will know how it should determine the persistency of the connection
		}
		if(o instanceof HTTPMessage){
			if(!isinitialized) System.out.println("TEST PORT NOT INITIALIZED"); //test port error - TODO
			if(o instanceof SC_request_HTTPMessage){
				HTTPRequest r = ((SC_request_HTTPMessage)o).request;
				String method = new String(r.method.value);
				String major = Integer.toString(r.version_major.value.intValue());
				String minor = Integer.toString(r.version_minor.value.intValue());
				pw.println(method + " / HTTP/" + major + "." + minor);
					for(HeaderLine h : r.header.value){
					String header_name = new String(h.header_name.value);
					String header_value = new String(h.header_value.value);
					pw.println(header_name + ": " + header_value);
					if(header_name.equals("Connection"))
						if(header_value.equals("close"))
							ispersistent=false;
				}
				pw.println();
				pw.flush();
			}
		}
	}
	class TestPortDaemon extends Thread{
		private TP_HTTPmsg_PT testport;
		public TestPortDaemon(TP_HTTPmsg_PT p){
			testport = p;
		}
		public void run(){
			try{testport.socketon.take();}catch(Exception e){e.printStackTrace();}
			try {
				BufferedReader br = new BufferedReader(new InputStreamReader(s.getInputStream()));
				String t;
				int state=0; //0 -- start line, 1 -- header fields, 2 -- body
				testport.isinitialized=true;
				//decomposing the incoming message - persistence can be asked for in the header, in this implementation any line of the incoming message can set the connection to be persistent
				//messages received here can only be HTTP messages from the other side, no ASPs
				if(testport.isclient){//persistence will be decided by this side in an outgoing message.
					SC_response_HTTPMessage msg=new SC_response_HTTPMessage(); //currently built message
					String body=new String("");
					boolean startlineOK=false; //during processing these have to be set
					boolean headerfldOK=true;
					for(;;){
						t = br.readLine(); //this is a reply from the SUT so persistence was already decided in the preceding request
						if(testport.ispersistent){ //body length indicates the end of the HTTP message
							//TODO
							//if end of message is reached, decomposition is ready, and message is put in the input queue - TODO
						}else{ //non-persistent
							if(t==null){ //null indicates the end of the HTTP message
								msg.response.body=new CHARSTRING(body);
								System.out.println(msg);
								if(startlineOK&&headerfldOK) testport.port.enqueue(msg);
								break;
							}
							if(state==0){ //start line
								while(t.equals("")) t=br.readLine(); //ignoring CRLFs at the beginning of the message, according to the standard
								boolean exception=false;
								try{
									String version=t.split("/")[1].split(" ")[0];
									msg.response=new HTTPResponse();
									msg.response.client_id=new INTEGER();//these two lines will have to be updated once client ids are handled
									msg.response.client_id.omitField=true;
									msg.response.version_major=new INTEGER(version.split("\\.")[0]);
									msg.response.version_minor=new INTEGER(version.split("\\.")[1]);
									msg.response.statuscode=new INTEGER(t.split(" ")[1]);
									msg.response.statustext=new CHARSTRING(t.split(" ",2)[1].split(" ",2)[1]);
									state=1;
								}catch(Exception e){
									e.printStackTrace();
									exception=true;
								}
								if(!exception) startlineOK=true; //must have a start line so it is false by default and only becomes true if no exception occurred during parsing the first line
							}else if(state==1){ //header fields
								if(msg.response.header==null) msg.response.header=new HeaderLines(new Vector<HeaderLine>());
								if(t.equals("")){
									state=2;
								}
								else
									try{
										String headerfield = t.split(":",2)[0];
										String headervalue = t.split(":",2)[1];
										int hvalsplitlen=headervalue.split(" ").length;
										msg.response.header.value.add(new HeaderLine(new CHARSTRING(headerfield), new CHARSTRING(headervalue.split(" ")[hvalsplitlen-1])));
										System.out.println("header "+msg.response.header);
									}catch(Exception e){
										e.printStackTrace();
										headerfldOK=false; //header fields are optional so header is OK by default and only becomes not OK if -- before the empty line preceding the body -- a line cannot be parsed as a header 
									}
							}else if(state==2){
								body+=t+"\n";
							}
						}
					}
				}else{//persistence will be decided by connecting peer in an incoming message header
					//TODO
				}
				br.close();
			} catch (Exception e) {e.printStackTrace();}
		}
	}
}
