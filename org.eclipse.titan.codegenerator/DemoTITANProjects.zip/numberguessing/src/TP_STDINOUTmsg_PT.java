package org.eclipse.titan.codegenerator.javagen;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner; 
import org.eclipse.titan.codegenerator.TTCN3JavaAPI.*;
public class TP_STDINOUTmsg_PT {
	private STDINOUTmsg_PT port;
	public TP_STDINOUTmsg_PT(STDINOUTmsg_PT p){
		port=p;
	}
	//must block until map is done
	public void user_map(String remotecomp, String remoteport){
		new TestPortDaemon(this).start();
	}
	//must block until unmap is done
	public void user_unmap(String remotecomp, String remoteport){ 
	}
	public void user_send(Object o){
		System.out.println("TESTPORT OUTPUT " + ((CHARSTRING)o).toString());
	}
	class TestPortDaemon extends Thread{
		private TP_STDINOUTmsg_PT testport;
		public TestPortDaemon(TP_STDINOUTmsg_PT p){
			testport = p;
		}
		public void run(){
			testport.port.mapped=true;
			Scanner scanner = new Scanner(System.in);
			for(;;){
				String inmsg = scanner.nextLine();
				testport.port.enqueue(new CHARSTRING(inmsg));
			}
		}
	}
}
